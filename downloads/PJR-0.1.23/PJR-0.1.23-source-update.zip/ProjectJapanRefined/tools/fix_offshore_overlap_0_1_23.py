#!/usr/bin/env python3
"""Pinned, offline repair of the source-verified Okayama 5100/5200 overlap.

Reads the unmodified 0.1.22 JAR. Only the one reviewed inland-water component
is reclassified as ocean; all dry land and every other water component survive.
"""
import argparse,gzip,hashlib,json,math,struct,zipfile,io
from pathlib import Path
import numpy as np
from scipy import ndimage
from remove_port_spurs import mask_from,coarse,xy
from compact_coast import packed_mask,signed_varints
from PIL import Image
import mapbox_vector_tile.decoder as decoder
from shapely import contains_xy,make_valid,union_all
from shapely.geometry import shape
ROOT=Path(__file__).resolve().parents[1]
PREFIX='assets/pjr/terrain/urban-coast/'
BASE='a3826c732ebb5ba27b8d222eb699e4d4fe70be26f4c33b148b0734d60b0c40db'
def digest(b):return hashlib.sha256(b).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--baseline-jar',type=Path,required=True);args=ap.parse_args()
 assert digest(args.baseline_jar.read_bytes())==BASE
 proof=json.loads((ROOT/'data/okayama-overlap-0.1.23/source-verification.json').read_text())
 assert proof['pixels']==1587206 and len(proof['tiles'])==14
 for t in proof['tiles']:
  assert t['selected']==t['source_sea'] and t['coastline']==t['measured_dem']==0
  for s in t['sources']:
   assert digest((ROOT/'data/okayama-overlap-0.1.23'/s['file']).read_bytes())==s['sha256']
 tiles={};original={}
 with zipfile.ZipFile(args.baseline_jar) as z:
  for name in z.namelist():
   if not name.startswith(PREFIX+'packs/') or not name.endswith('.pck'):continue
   b=z.read(name);original[name]=b;_,bx,by=map(int,Path(name).stem.split('-'))
   magic,n=struct.unpack_from('>IH',b);assert magic==0x504a5250;start=6+9*n
   for i in range(n):
    slot,off,size=struct.unpack_from('>BII',b,6+9*i);tiles[(bx*4+slot%4,by*4+slot//4)]=b[start+off:start+off+size]
 x0,y0=map(int,xy(133.60,34.66));x1,y1=map(int,xy(134.10,34.40))
 mask=np.block([[mask_from(tiles[(x,y)]) for x in range(x0,x1+1)] for y in range(y0,y1+1)])
 labels,n=ndimage.label(mask==2)
 tx,ty=xy(134.06455618458898,34.56003585627021)
 label=labels[int((ty-y0)*512),int((tx-x0)*512)];assert label>0
 selected=labels==label;assert selected.sum()==1587206
 assert np.all(mask[ndimage.binary_dilation(selected)&~selected]==1)
 del labels
 # Re-derive the proof from the bundled official source bytes, not only the
 # recorded audit counts. This is an offline source-build operation.
 for t in proof['tiles']:
  x,y=t['tile'];local=selected[(y-y0)*512:(y-y0+1)*512,(x-x0)*512:(x-x0+1)*512]
  source=ROOT/'data/okayama-overlap-0.1.23'
  data=decoder.TileData((source/f'optimal_bvmap-v1-14-{x}-{y}.pbf').read_bytes(),default_options={'y_coord_down':True}).get_message()
  wa=data['WA'];coord=(np.arange(512)+.5)*wa['extent']/512
  sea=union_all([make_valid(shape(f['geometry']))for f in wa['features']if f['properties'].get('vt_code')==5100])
  assert np.all(contains_xy(sea,coord[None,:],coord[:,None])[local])
  coast=data.get('Cstline',dict(extent=4096,features=[]));lines=union_all([make_valid(shape(f['geometry']))for f in coast['features']]).buffer(2*coast['extent']/512)
  c=(np.arange(512)+.5)*coast['extent']/512
  assert not contains_xy(lines,c[None,:],c[:,None])[local].any()
  dem=(source/f'dem_png-14-{x}-{y}.png').read_bytes()
  if dem:
   rgb=np.asarray(Image.open(io.BytesIO(dem)).convert('RGB'));valid=((rgb[:,:,0]!=128)|(rgb[:,:,1]!=0)|(rgb[:,:,2]!=0)).repeat(2,0).repeat(2,1)
   assert not valid[local].any()
 before=mask.copy();old=coarse(mask);mask[selected]=1;fields=coarse(mask)
 assert np.array_equal(mask==0,before==0),'Never remove a dry-land pixel'
 assert np.array_equal(mask!=0,before!=0),'Water union must be identical'
 assert np.all(mask[~selected]==before[~selected])
 assert np.array_equal(old[1],fields[1])
 different=(old[0]!=fields[0]);del old
 pixel=40075016.68557849/16384/512*math.cos(math.radians((34.40+34.66)/2))
 changed=[]
 for y in range(y0,y1+1):
  for x in range(x0,x1+1):
   px=(x-x0)*512;py=(y-y0)*512;ax=max(0,px-48);ay=max(0,py-48);bx=min(mask.shape[1],px+560);by=min(mask.shape[0],py+560)
   cy=np.minimum(np.arange(65)+py//8,fields[0].shape[0]-1);cx=np.minimum(np.arange(65)+px//8,fields[0].shape[1]-1)
   if not(selected[ay:by,ax:bx].any() or different[cy[:,None],cx[None,:]].any()):continue
   local=mask[ay:by,ax:bx];raw=bytearray(struct.pack('>6Id',0x504a5243,1,local.shape[1],local.shape[0],px-ax,py-ay,pixel));raw+=packed_mask(local)
   for f in fields:
    values=f[cy[:,None],cx[None,:]];delta=values.copy();delta[1:,:]-=values[:-1,:];delta[:,1:]-=delta[:,:-1].copy();raw+=signed_varints(delta)
   raw+=struct.pack('>I',0)
   encoded=gzip.compress(raw,compresslevel=9,mtime=0)
   changed.append(dict(x=x,y=y,before_sha256=digest(tiles[(x,y)]),after_sha256=digest(encoded)));tiles[(x,y)]=encoded
 packs={}
 for (x,y),b in tiles.items():packs.setdefault((x//4,y//4),[]).append(((y%4)*4+x%4,b))
 assets=[]
 for (x,y),rows in sorted(packs.items()):
  head=bytearray(struct.pack('>IH',0x504a5250,len(rows)));body=bytearray()
  for slot,b in sorted(rows):head+=struct.pack('>BII',slot,len(body),len(b));body+=b
  data=bytes(head+body);name=PREFIX+f'packs/14-{x}-{y}.pck'
  if data!=original[name]:assets.append(dict(path=name,before_sha256=digest(original[name]),after_sha256=digest(data)))
  (ROOT/'src/main/resources'/name).write_bytes(data)
 report=dict(baseline_jar_sha256=BASE,source_proof='data/okayama-overlap-0.1.23/source-verification.json',region='okayama',seed_lon_lat=[134.06455618458898,34.56003585627021],seed_world=[-257820,62406],reclassified_pixels=1587206,dry_land_pixels_changed=0,all_water_mask_pixels_changed=0,changed_tiles=changed,changed_assets=assets,policy='Only source-verified ocean overlapping inland-water class; all original dry land and other inland-water components preserved.')
 (ROOT/'docs/okayama-overlap-0.1.23.json').write_text(json.dumps(report,indent=2)+'\n')
 print('OKAYAMA REPAIR PASS',len(changed),'tiles',len(assets),'packs',flush=True)
if __name__=='__main__':main()
