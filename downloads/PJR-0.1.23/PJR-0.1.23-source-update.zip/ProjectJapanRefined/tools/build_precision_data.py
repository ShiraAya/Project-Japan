#!/usr/bin/env python3
"""Fetch actual GSI elevations and urban coastline polygons; never upscale old DEM as new data.

National DEM z12, urban DEM z14, urban vector z14 sampled at 512 pixels/tile.
Source downloads are immutable, hashed and resumable. Runtime data are sparse, tiled and offline.
"""
from pathlib import Path
import os
import argparse, concurrent.futures as cf, gzip, hashlib, io, json, math, struct, threading, time
import numpy as np
from PIL import Image
from scipy import ndimage
import requests

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'src/main/resources/assets/pjr/terrain'
CACHE=ROOT/'source-archives/precision-0.1.15'
LOCK=ROOT/'data/precision-source-lock.json'
REGIONS={
 'tokyo': [139.57,35.22,140.15,35.78],
 'osaka-kobe': [135.12,34.34,135.62,34.80],
 'nagoya': [136.60,34.78,136.98,35.15],
 'fukuoka': [130.26,33.56,130.47,33.73],
 'kitakyushu': [130.68,33.80,131.08,34.02],
 'hiroshima': [132.33,34.27,132.58,34.41],
 'okayama': [133.60,34.40,134.10,34.66],
 'sendai': [140.91,38.12,141.13,38.37],
 'niigata': [138.91,37.84,139.31,38.04],
 'shizuoka': [138.36,34.86,138.59,35.10],
 'hamamatsu': [137.50,34.62,137.92,34.82],
 'kumamoto': [130.53,32.68,130.65,32.85],
 'kagoshima': [130.49,31.40,130.65,31.65],
 'naha': [127.59,26.10,127.75,26.32],
 'hakodate': [140.62,41.70,140.84,41.86],
 'tomakomai': [141.54,42.56,141.97,42.68],
}
records=json.loads(LOCK.read_text()) if LOCK.exists() else {}
mutex=threading.Lock();sessions=threading.local()
def xy(lon,lat,z):
 return (np.asarray(lon)+180)/360*(1<<z),(1-np.arcsinh(np.tan(np.deg2rad(lat)))/np.pi)/2*(1<<z)
def bounds_tiles(bounds,z):
 w,s,e,n=bounds;x0,y0=xy(w,n,z);x1,y1=xy(e,s,z)
 return int(x0),int(y0),int(x1),int(y1)
def save_lock():
 with mutex:
  LOCK.write_text(json.dumps(records,sort_keys=True,indent=2)+'\n')
def fetch(key,url):
 path=CACHE/key;path.parent.mkdir(parents=True,exist_ok=True)
 if path.exists():data=path.read_bytes()
 else:
  if not hasattr(sessions,'s'):sessions.s=requests.Session()
  for attempt in range(4):
   try:
    r=sessions.s.get(url,timeout=30)
    if r.status_code==404:data=b'';break
    r.raise_for_status();data=r.content;break
   except (requests.RequestException,OSError):
    if attempt==3:raise
    time.sleep(.2*(attempt+1))
  path.write_bytes(data)
 digest=hashlib.sha256(data).hexdigest()
 with mutex:
  old=records.get(key)
  if old:assert old['sha256']==digest,'Source cache changed: '+key
  records[key]={'url':url,'sha256':digest,'bytes':len(data)}
 return data
def dem_plan():
 mask=np.asarray(Image.open(OUT/'japan_land_hd.png'))
 iy,ix=np.nonzero(mask>=128)
 tx,ty=xy(122+ix*32/(mask.shape[1]-1),46-iy*26/(mask.shape[0]-1),12)
 ids=np.unique((tx.astype('int64')<<16)|ty.astype('int64'))
 keys={(12,int(k>>16)+dx,int(k&65535)+dy) for k in ids for dx,dy in [(0,0),(-1,0),(1,0),(0,-1),(0,1)]}
 for bounds in REGIONS.values():
  for z in [12,14]:
   x0,y0,x1,y1=bounds_tiles(bounds,z)
   keys.update((z,x,y) for x in range(x0-1,x1+2) for y in range(y0-1,y1+2))
 return sorted(keys)
def compile_dem():
 dest=OUT/'dem-atlas';dest.mkdir(exist_ok=True)
 keys=dem_plan();print('DEM requests',len(keys),flush=True)
 def one(key):
  z,x,y=key;name=f'{z}/{x}/{y}';b=fetch('dem/'+name+'.png',f'https://cyberjapandata.gsi.go.jp/xyz/dem_png/{name}.png')
  if not b:return None
  a=np.asarray(Image.open(io.BytesIO(b)).convert('RGB'),dtype='int32');v=a[:,:,0]*65536+a[:,:,1]*256+a[:,:,2]
  h=np.where(v>=8388608,v-16777216,v)*.01
  valid=v!=8388608
  if not valid.any():return None
  # Half-metre quantization is below a 2 m world block; retain negative dry-ground elevations.
  q=np.where(valid,np.clip(np.rint(h*2),-32767,32767),-32768).astype('>i2')
  # Lossless two-dimensional differences make smooth terrain much smaller in the JAR.
  delta=q.astype('int32');delta[1:,:]-=q[:-1,:].astype('int32');delta[:,1:]-=delta[:,:-1].copy()
  target=dest/f'{z}-{x}-{y}.bin.gz';target.write_bytes(gzip.compress(delta.astype('>i2').tobytes(),mtime=0))
  return (z,x,y,int(valid.sum()),len(b),target.stat().st_size)
 results=[]
 with cf.ThreadPoolExecutor(max_workers=int(os.environ.get("PJR_SOURCE_WORKERS",16))) as pool:
  for i,r in enumerate(pool.map(one,keys)):
   if r:results.append(r)
   if i%100==0:save_lock();print('DEM',i+1,'/',len(keys),'valid',len(results),flush=True)
 (dest/'index.tsv').write_text('# predictor=2; GSI DEM10B; z x y; half metres; -32768 missing\n'+''.join(f'{z}\t{x}\t{y}\n' for z,x,y,*_ in results))
 report={'source':'GSI DEM10B PNG','national_zoom':12,'urban_zoom':14,'baseline_zoom':9,'requested_tiles':len(keys),'valid_tiles':len(results),'valid_samples':sum(r[3] for r in results),'compressed_bytes':sum(r[5] for r in results),'by_zoom':{str(z):sum(r[0]==z for r in results) for z in [12,14]},'regions':REGIONS,'sample_spacing':'Web Mercator pixel spacing; about 31 m at Tokyo for z12, 7.8 m for z14; not a nationwide 5 m DEM','missing_policy':'Preserve nodata; fallback to lower resolution or inherited regional sources.'}
 (ROOT/'docs/precision-dem-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');save_lock();print(report,flush=True)

def compile_coasts(selected):
 # Reuse only the GSI PMTiles transport, not the old Tokyo water repair algorithm.
 import compile_coastal_regions as transport
 import mapbox_vector_tile.decoder as decoder
 from shapely.geometry import shape
 from shapely import contains_xy,union_all,make_valid
 from ocean_coverage import repair_ocean_coverage, REPAIR_VERSION
 if os.environ.get("PJR_COAST_LOCK_SUFFIX"):
  transport.LOCK=ROOT/"data"/("gsi-coastal-"+os.environ["PJR_COAST_LOCK_SUFFIX"]+"-source-lock.json")
  if transport.LOCK.exists():
   prior=json.loads(transport.LOCK.read_text());transport.records.update(prior);transport.old.update(prior)
 transport.reader.metadata()
 dest=OUT/'urban-coast';dest.mkdir(exist_ok=True)
 national_mask=np.asarray(Image.open(OUT/'japan_land_ocean.png'))
 size=512;pad=48;reports=[];index=[]
 for name,bounds in REGIONS.items():
  if selected and name not in selected:continue
  x0,y0,x1,y1=bounds_tiles(bounds,14)
  tiles=[(x,y) for y in range(y0,y1+1) for x in range(x0,x1+1)]
  mask=np.zeros(((y1-y0+1)*size,(x1-x0+1)*size),dtype='uint8')
  print('COAST',name,'tiles',len(tiles),'grid',mask.shape,flush=True)
  def tile(t):
   x,y=t;b=transport.vector_tile(14,x,y)
   def proven_open_sea():
    # GSI omits some featureless open-sea tiles. Require two independent sea signals.
    lons=(x+(np.arange(16)+.5)/16)/(1<<14)*360-180
    lats=np.rad2deg(np.arctan(np.sinh(np.pi*(1-2*(y+(np.arange(16)+.5)/16)/(1<<14)))))
    ix=np.rint((lons-122)/32*(national_mask.shape[1]-1)).astype(int)
    iy=np.rint((46-lats)/26*(national_mask.shape[0]-1)).astype(int)
    db=fetch(f'dem/14/{x}/{y}.png',f'https://cyberjapandata.gsi.go.jp/xyz/dem_png/14/{x}/{y}.png')
    valid_dem=False
    if db:
     rgb=np.asarray(Image.open(io.BytesIO(db)).convert('RGB'));valid_dem=bool(np.any((rgb[:,:,0]!=128)|(rgb[:,:,1]!=0)|(rgb[:,:,2]!=0)))
    return not (np.any(national_mask[iy[:,None],ix[None,:]]>=128) or valid_dem)
   if not b:
    if not proven_open_sea():raise ValueError(f"Missing vector tile over possible land {name} {x} {y}")
    return x,y,np.ones((size,size),dtype="uint8")
   # Keep decoded coordinates explicitly in tile/image orientation (north at y=0).
   td=decoder.TileData(b, default_options={'y_coord_down': True})
   for i in reversed(range(len(td.tile.layers))):
    if td.tile.layers[i].name!='WA':del td.tile.layers[i]
   data=td.get_message().get('WA',{'features':[],'extent':4096})
   # Some PMTiles coverage holes occupy only part of a featureless sea tile.
   # An all-ocean legacy mask plus entirely missing DEM permits filling those gaps.
   if not any(f['properties'].get('vt_code')==5200 for f in data['features']) and proven_open_sea():
    return x,y,np.ones((size,size),dtype='uint8')
   sea=[];water=[]
   for f in data['features']:
    code=f['properties'].get('vt_code',0)
    if code not in (5100,5200):raise ValueError('Unexpected z14 water class '+str(code))
    p=make_valid(shape(f['geometry']))
    if code==5100:sea.append(p)
    else:water.append(p)
   coord=(np.arange(size)+.5)*data['extent']/size
   result=np.zeros((size,size),dtype='uint8')
   if water:result[contains_xy(union_all(water),coord[None,:],coord[:,None])]=2
   # GSI WA may contain coincident 5100/5200 offshore rectangles. Explicit
   # ocean ownership wins there; otherwise inland-water ownership becomes dry
   # terrain when no authored river/lake exists (Okayama regression, 0.1.23).
   if sea:result[contains_xy(union_all(sea),coord[None,:],coord[:,None])]=1
   return x,y,result
  classified=CACHE/f'{name}-classified.npy'
  mask_audit=CACHE/f'{name}-mask-audit.json'
  if classified.exists():
   mask=np.load(classified);removed=tiny=0
   previous=mask_audit if mask_audit.exists() else ROOT/f'docs/urban-coast-{name}-audit.json'
   if previous.exists():
    old_report=json.loads(previous.read_text());removed=old_report['removed_enclosed_sea_nodes'];tiny=old_report['removed_tiny_land_nodes']
   pixel_m=40075016.68557849/(1<<14)/size*math.cos(math.radians((bounds[1]+bounds[3])/2))
  else:
   with cf.ThreadPoolExecutor(max_workers=int(os.environ.get("PJR_SOURCE_WORKERS",16))) as pool:
    futures=[pool.submit(tile,t) for t in tiles]
    for i,future in enumerate(cf.as_completed(futures)):
     try:x,y,a=future.result()
     except Exception as exc:
      print('COAST SOURCE FAILURE',name,str(exc),flush=True)
      for pending in futures:pending.cancel()
      raise
     mask[(y-y0)*size:(y-y0+1)*size,(x-x0)*size:(x-x0+1)*size]=a
     if i%50==0:
      with transport.mutex:snapshot=dict(transport.records)
      transport.LOCK.write_text(json.dumps(snapshot,indent=2)+'\n');print(name,i+1,'/',len(tiles),flush=True)
   # Inland river/lake polygons never become sea. Also remove disconnected marine fragments.
   labels,n=ndimage.label(mask==1)
   edge=np.unique(np.r_[labels[0],labels[-1],labels[:,0],labels[:,-1]])
   keep=np.zeros(n+1,dtype=bool);keep[edge]=True;keep[0]=True
   enclosed=(labels>0)&~keep[labels];removed=int(enclosed.sum());mask[enclosed]=0
   del labels,enclosed
   # Tiny detached land specks below ~64 m2 have no useful block-scale footprint.
   pixel_m=40075016.68557849/(1<<14)/size*math.cos(math.radians((bounds[1]+bounds[3])/2))
   labels,n=ndimage.label(mask==0);counts=np.bincount(labels.ravel());small=counts*pixel_m**2<64;small[0]=False
   small[np.unique(np.r_[labels[0],labels[-1],labels[:,0],labels[:,-1]])]=False
   touches_sea=np.zeros(n+1,dtype=bool)
   touches_sea[np.unique(labels[ndimage.binary_dilation(mask==1)])]=True
   small &= touches_sea
   dots=small[labels];tiny=int(dots.sum());mask[dots]=1;del labels,dots
   np.save(classified,mask)
   mask_audit.write_text(json.dumps({'removed_enclosed_sea_nodes':removed,'removed_tiny_land_nodes':tiny})+'\n')
  previous_audit=json.loads(mask_audit.read_text()) if mask_audit.exists() else {}
  coverage_repair=previous_audit.get('ocean_coverage_repair', {})
  if coverage_repair.get('version') != REPAIR_VERSION:
   def source_dem(x,y):
    return fetch(f'dem/14/{x}/{y}.png',f'https://cyberjapandata.gsi.go.jp/xyz/dem_png/14/{x}/{y}.png')
   coverage_repair=repair_ocean_coverage(mask,x0,y0,national_mask,transport.vector_tile,source_dem)
   np.save(classified,mask)
   mask_audit.write_text(json.dumps({'removed_enclosed_sea_nodes':removed,'removed_tiny_land_nodes':tiny,
       'ocean_coverage_repair':coverage_repair},indent=2)+'\n')
   save_lock()
   print('COAST COVERAGE',name,coverage_repair['filled_nodes'],'repaired nodes',flush=True)
  coarse_fields=[]
  for wet in [mask[::8,::8]==1,mask[::8,::8]!=0]:
   coarse_fields.append(((ndimage.distance_transform_edt(~wet)-ndimage.distance_transform_edt(wet))*pixel_m*8).astype('float32'))
  for x,y in tiles:
   px=(x-x0)*size;py=(y-y0)*size
   ay=max(0,py-pad);by=min(mask.shape[0],py+size+pad);ax=max(0,px-pad);bx=min(mask.shape[1],px+size+pad)
   local=mask[ay:by,ax:bx];arrays=[]
   for channel,wet in enumerate([local==1,local!=0]):
    if wet.all():distance=np.full(wet.shape,-128.,dtype='float32')
    elif not wet.any():distance=np.full(wet.shape,128.,dtype='float32')
    else:distance=(ndimage.distance_transform_edt(~wet)-ndimage.distance_transform_edt(wet))*pixel_m
    fine=distance[py-ay:py-ay+size,px-ax:px-ax+size]
    cy,cx=np.meshgrid((np.arange(size)+py)/8,(np.arange(size)+px)/8,indexing='ij')
    coarse=ndimage.map_coordinates(coarse_fields[channel],[cy,cx],order=1,mode='nearest')
    t=np.clip((np.abs(fine)-64)/48,0,1);t=t*t*(3-2*t)
    merged=fine+(coarse-fine)*t
    a=np.clip(np.rint(merged*8),-32760,32760).astype('>i2');arrays.append(a)
   # One-sample halo permits seam-correct runtime bilinear queries using adjacent atlas tiles.
   values=np.stack(arrays).astype('float64')/8
   codes=(np.sign(values)*np.minimum(127,np.rint(np.log2(1+2*np.abs(values))*9))).astype('int32')
   delta=codes.copy();delta[:,1:,:]-=codes[:,:-1,:];delta[:,:,1:]-=delta[:,:,:-1].copy()
   raw=delta.astype('int8').tobytes()
   (dest/f'{x}-{y}.bin.gz').write_bytes(gzip.compress(raw,compresslevel=6,mtime=0))
   index.append((x,y))
   if len(index)%100==0:print("COAST ENCODE",name,len(index),flush=True)
  report={'name':name,'bounds':bounds,'tiles':len(tiles),'grid':list(mask.shape),'pixel_metres_centre':pixel_m,'sea_nodes':int((mask==1).sum()),'inland_water_mask_nodes':int((mask==2).sum()),'removed_enclosed_sea_nodes':removed,'removed_tiny_land_nodes':tiny,'signed_distance_radius_metres':4095,'encoding':'log2-byte-delta; 9 bins/octave; sign preserved','classification':'5100 ocean only; 5200 masks existing hydrology, never new sea or automatic sea-level rivers'}
  report['ocean_coverage_repair']=coverage_repair
  reports.append(report);(ROOT/f'docs/urban-coast-{name}-audit.json').write_text(json.dumps(report,indent=2)+'\n')
  del mask
  transport.LOCK.write_text(json.dumps(transport.records,indent=2)+'\n')
  print('COAST DONE',report,flush=True)
 # Use all existing completed region files so a resumed selected pass is safe.
 completed=[json.loads(p.read_text()) for p in sorted((ROOT/'docs').glob('urban-coast-*-audit.json'))]
 (dest/'regions.tsv').write_text('# id west south east north\n'+''.join(r['name']+'\t'+'\t'.join(map(str,r['bounds']))+'\n' for r in completed))
 (dest/'index.tsv').write_text('# log2-byte-delta; z14 x y; 512x512 sea/all-water signed distance\n'+''.join(p.stem.removesuffix('.bin').replace('-','\t')+'\n' for p in sorted(dest.glob('*.bin.gz'))))
 (ROOT/'docs/urban-coast-audit.json').write_text(json.dumps(completed,indent=2)+'\n')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['dem','coast']);p.add_argument('--regions',nargs='*');a=p.parse_args()
 CACHE.mkdir(parents=True,exist_ok=True)
 if a.mode=='dem':compile_dem()
 else:compile_coasts(a.regions)
