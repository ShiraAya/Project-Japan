#!/usr/bin/env python3
"""Append audited original W05 routes; preserve every prior geographic record exactly."""
import argparse,io,json,gzip,hashlib,struct,zipfile,math
from pathlib import Path
import numpy as np
from expand_water_0_1_19 import read_geo
ROOT=Path(__file__).resolve().parents[1]
BASE='a3826c732ebb5ba27b8d222eb699e4d4fe70be26f4c33b148b0734d60b0c40db'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--baseline-jar',type=Path,required=True);args=ap.parse_args()
 assert hashlib.sha256(args.baseline_jar.read_bytes()).hexdigest()==BASE
 with zipfile.ZipFile(args.baseline_jar) as z:raw=gzip.decompress(z.read('assets/pjr/world/geography.pjrg.gz'));shapes=z.read('assets/pjr/world/river-shapes.properties').decode()
 header,lakes,old=read_geo(raw);assert len(lakes)==221 and len(old)==356
 data=json.loads((ROOT/'data/lake-connections-0.1.23.json').read_text());rivers=data['routes'];assert len(rivers)==33
 names={r['name'] for r in old};new=[];aliases={}
 for r in rivers:
  original=r['name'];name=original
  if name in names:name+='（'+('河口湖' if r['terminal_lake']=='W09:gc01_321' else '追加水系')+'）'
  assert name not in names;names.add(name);aliases[original]=name
 for r in rivers:
  assert not r['bridges'],'No inferred bridges accepted'
  for k in ['terminal_gap','source_gap','parent_gap']:
   assert r[k] is None or r[k]<3,(r['name'],k,r[k])
  p=np.asarray(r['points']);assert np.isfinite(p).all()
  name=aliases[r['name']];width=round(min(80,14+math.sqrt(r['route_km'])*6),1)
  row={k:v for k,v in r.items() if k!='points'};row.update(name=name,official_name=r['name'],mouth_width_m=width,max_depth_blocks=4,source_width_m=4)
  new.append(row)
 b=io.BytesIO();b.write(header)
 def integer(n):b.write(struct.pack('>i',n))
 def text(s):v=s.encode();integer(len(v));b.write(v)
 integer(len(lakes))
 for l in lakes:b.write(l['bytes'])
 integer(len(old)+len(rivers))
 for r in old:b.write(r['bytes'])
 for r,s in zip(rivers,new):
  for v in [s['name'],r['code'],r['source_lake'],r['terminal_lake'],aliases.get(r['parent'],r['parent'])]:text(v)
  p=np.asarray(r['points'],dtype='>f8');integer(len(p));b.write(p.tobytes())
  shapes+='\n'+s['name'].encode('unicode_escape').decode()+f"={s['mouth_width_m']},4,4"
 packed=gzip.compress(b.getvalue(),compresslevel=9,mtime=0)
 # Same gzip format and exact decompressed bytes; only the build-time compressor changes.
 import zopfli.gzip
 optimized=zopfli.gzip.compress(b.getvalue(),numiterations=5)
 assert gzip.decompress(optimized)==b.getvalue()
 if len(optimized)<len(packed):packed=optimized
 dest=ROOT/'src/main/resources/assets/pjr/world';(dest/'geography.pjrg.gz').write_bytes(packed);(dest/'river-shapes.properties').write_text(shapes+'\n')
 _,ll,rr=read_geo(b.getvalue());assert all(a['bytes']==b['bytes'] for a,b in zip(lakes,ll));assert all(a['bytes']==b['bytes'] for a,b in zip(old,rr))
 report=dict(baseline_jar_sha256=BASE,original_lakes=221,original_rivers=356,total_rivers=len(rr),added_rivers=new,source_locks=data['source_locks'],old_records_byte_identical=True,inferred_dry_land_bridges=0,raw_sha256=hashlib.sha256(b.getvalue()).hexdigest(),geography_gzip_bytes=len(packed),cross_section_note='Widths and bed depths are visual model parameters, not measured bathymetry. W05 geometry does not imply perennial discharge.',limitations=['W05 is a dated geographic snapshot; engineered pipes/tunnels and unverified channels are not synthesized.','ウツナイ川 includes the connected main component; a separate 1.691 km component is retained only in the audit.','前川 uses the contiguous official 木場潟 centerline as well as its named W05 river segments.'])
 (ROOT/'docs/water-connections-0.1.23.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 selection=json.loads((ROOT/'data/selection.json').read_text());selection['rivers']=[r for r in selection['rivers'] if r['id'] not in {n['name'] for n in new}]
 for n in new:selection['rivers'].append(dict(id=n['name'],river_code=n['code'],mouth_width_m=n['mouth_width_m'],source_width_m=4,max_depth_blocks=4))
 (ROOT/'data/selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n')
 print('APPENDED',len(new),'total',len(rr),'gzipBytes',len(packed),flush=True)
if __name__=='__main__':main()
