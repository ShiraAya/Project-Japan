import sys,io,gzip,json,zipfile,collections,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tools'))
import compile_geography as c
from expand_water_0_1_19 import read_geo
import numpy as np,shapefile
from shapely.geometry import LineString,Point
_,lakes,old=read_geo(gzip.decompress((R/'src/main/resources/assets/pjr/world/geography.pjrg.gz').read_bytes()));lake={l['id']:l for l in lakes};oldroutes={r['name']:r for r in old}
for l in lakes:
 if l['name'] in ['Biwa','Ogawara']:print('LAKE',l['id'],l['name'])
# code / official W05 name / terminal lake / source lake / downstream river
specs=[
('8303070135','寺川','321','',''),('8303070133','西川','321','',''),('8303070132','梨川','321','',''),
('1900010005','三沢川','320','',''),('1900010003','桑留尾川','320','',''),('1900010009','本沢川','320','',''),('1900020003','精進川','314','',''),
('8606070118','真名川','','','Kuzuryu'),('8606070133','蝿帽子川','300','',''),('8606070131','小沢川','300','',''),
('8606041180','長命寺川','Biwa','420',''),('8606041195','安土川','420','',''),('8606041188','蛇砂川','420','',''),('8606041190','山本川','420','',''),
('8909050001','嘉瀬川','','',''),('8909050047','初瀬川','525','',''),
('0100200001','シブノツナイ川','','',''),('0100200003','中の沢川','18','',''),
('8202060011','姉沼川','Ogawara','',''),('0202190001','二又川','','',''),
('8101090000','シラルトロエトロ川','','','Kushiro'),
('2200810021','釣橋川','Hamana','',''),('2200810035','宇志川','399','',''),('2200810022','西神田川','399','',''),('2200810026','都筑大谷川','399','',''),('2200810033','北込川','399','',''),
('8404120001','梯川','','',''),('8404120002','前川','','295','梯川'),('8404120004','日用川','295','',''),
('8202120025','梵字川','','184','Aka'),('8202120032','湯屋俣川','184','',''),
('0100020000','ウツナイ川','13','',''),('0101120000','古小沼川','32','','')]
parts=collections.defaultdict(list);keys={(s[0],s[1]) for s in specs}|{('8404120003','木場潟')};locks=[]
for rec in json.loads((R/'data/source-lock.json').read_text()):
 path=R/'source-archives'/rec['filename']
 if not path.exists() or not rec['filename'].startswith('W05'):continue
 assert hashlib.sha256(path.read_bytes()).hexdigest()==rec['sha256'];locks.append(rec)
 with zipfile.ZipFile(path) as z:
  stem=next(n for n in z.namelist() if n.lower().endswith('_stream.shp'))[:-4]
  reader=shapefile.Reader(shp=io.BytesIO(z.read(stem+'.shp')),dbf=io.BytesIO(z.read(stem+'.dbf')),encoding='cp932',encodingErrors='replace')
  for row in reader.iterShapeRecords():
   attrs=row.record.as_dict();key=(attrs['W05_002'],attrs['W05_004'])
   if key not in keys:continue
   pts=c.project(row.shape.points);bb=list(row.shape.parts)+[len(pts)]
   for a,b in zip(bb,bb[1:]):
    if b-a>1 and c.length(pts[a:b])>.4:parts[key].append(pts[a:b])
 print('READ',rec['filename'],flush=True)
def lk(s):return next(l for l in lakes if l['id']=='W09:gc01_'+s or l['name']==s) if s else None
def lonlat(p):return [c.LON0+p[0]/c.SX,c.LAT0-p[1]/c.SZ]
dem=c.Dem();output=[]
for code,name,tl,sl,parent in specs:
 pp=parts[code,name]
 if name=='前川':pp=pp+parts['8404120003','木場潟']
 if not pp:print('MISSING',code,name,flush=True);continue
 ends=[p[i] for p in pp for i in [0,-1]]
 from scipy.spatial import cKDTree
 tree=cKDTree(ends);tips=[p for p in ends if len(tree.query_ball_point(p,12))==1]
 if tips:ends=tips
 out=None;source=None;terminal=lk(tl);start=lk(sl)
 if terminal:out=lonlat(min(ends,key=lambda p:terminal['polygon'].distance(Point(p))))
 elif parent and parent in oldroutes:
  line=LineString(oldroutes[parent]['points']);out=lonlat(min(ends,key=lambda p:line.distance(Point(p))))
 if start:
  source_ends=[p[i] for p in pp for i in [0,-1]] if name=='姉沼川' else ends
  source=lonlat(min(source_ends,key=lambda p:start['polygon'].distance(Point(p))))
 try:
  points,stats=c.route(pp,dem,out,source)
  rec=dict(code=code,name=name,terminal_lake=terminal['id'] if terminal else '',source_lake=start['id'] if start else '',parent=parent,points=points.tolist(),**stats)
  rec['endpoint_dem']=[dem.sample(points[0]),dem.sample(points[-1])]
  rec['lake_hits']=[(l['id'],l['name'],round(LineString(points).intersection(l['polygon']).length,2)) for l in lakes if LineString(points).intersects(l['polygon'])]
  rec['terminal_gap']=terminal['polygon'].distance(Point(points[-1])) if terminal else None
  rec['source_gap']=start['polygon'].distance(Point(points[0])) if start else None
  rec['parent_gap']=LineString(oldroutes[parent]['points']).distance(Point(points[-1])) if parent in oldroutes else None
  output.append(rec);oldroutes[name]=dict(points=points);print('ROUTE',name,{k:v for k,v in rec.items() if k!='points'},flush=True)
 except Exception as e:print('FAIL',name,str(e),flush=True)
(R/'data/lake-connections-0.1.23.json').write_text(json.dumps(dict(routes=output,source_locks=locks),ensure_ascii=False,indent=2))
