# 冈山海洋重叠分类证据

官方 GSI optimal_bvmap-v1 矢量及 dem_png 高程瓦片，2026-10-09 获取。每个源文件 URL、SHA-256 和字节数在 source-verification.json 中。

零字节 dem_png 文件代表已记录的官方 HTTP 404（该海面没有发布 DEM），不是损坏的 PNG。每个改动像素还必须同时通过显式海洋多边形覆盖、无海岸线穿过、原分类为水域三项验证，不能仅凭缺 DEM 删除陆地。

fix_offshore_overlap_0_1_23.py 会在构建时重新读取全部源几何验证上述条件。运行中的模组只读取已打包数据，不包含联网逻辑。

updated-probes.json 保存按同一经核实组件修正的 19 个历史分类夹具；坐标不变，类别由内陆水域改为海洋。
