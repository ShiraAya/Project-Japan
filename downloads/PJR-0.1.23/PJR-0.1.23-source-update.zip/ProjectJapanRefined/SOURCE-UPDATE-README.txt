Apply over ProjectJapanRefined-0.1.22-alpha-source.zip (SHA256 b65fc2685666ee84d7a1e6eee0b3f28bfe69d65f6d90b9de99d38379934649f9).
Extract into its parent folder, replacing matching files. This is a source update, not the installable mod.
The unchanged 0.1.22 files plus this patch reproduce the full 0.1.23 source tree.
