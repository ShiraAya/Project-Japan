# ProjectJapanRefined (PJR) 0.1.23-alpha

Minecraft 1.20.1 / Forge 47.4.20 / Java 17。AI 辅助编写。389 河、221 湖；比例 0.5:0.5:0.5，东京站 X=0、Z=0，海平面 Y=0，建造高度 -256 ≤ Y < 2000。

安装包 **49,816,835 字节**，严格低于 50,000,000 字节。地理数据全部内置；Minecraft、Forge、Java 已安装后，模组可完全离线运行，无首次地理数据下载。

本版修复冈山近海 X=-257820、Z=62406 的方形假陆地：GSI 的海洋/内陆水域多边形在这里重叠，旧编译顺序错误地覆盖海洋类别。经官方海岸线和高程核对，修正 1,587,206 个水域像素，原有陆地像素不变。

同时改善水库出口石质坡面的衔接，补入 33 条可追溯的 W05 河道。原有 356 河和 221 湖的几何、水位、纵向剖面指纹全部保持一致。15 个原先零连接的湖泊已有至少一条连接；仍有 12 个零连接记录，包含自然特征、人工输水设施及尚未完成的水道，不能一概解释为闭流湖。逐湖说明见 docs/LAKE-CONNECTION-AUDIT-0.1.23.md。

关闭游戏后替换旧 PJR，只保留一个 PJR JAR。世界类型「ProjectJapanRefined · 精修日本」，服务器 level-type=pjr:japan。在新世界或未生成区块查看，旧区块不会自动重塑。使用 PJM 时配套 1.3.10，其生产 Java 代码与 1.3.9 相同，仅更新离线地图数据及版本信息。

验证说明见 docs/VALIDATION.md。本次重编 Java 核心并复用固定 0.1.22 的未改 Forge 适配类，核查 ABI、禁网运行、河湖剖面、河岸和海岸分类。没有执行图形 Minecraft、完整 ForgeGradle、光照或流体 tick；诊断图不是实机截图。

开发环境依赖齐全时可用 ./gradlew clean check build。本次复现入口为 tools/build_feedback_release.py，需要固定的 0.1.22 JAR/源码。历史验证文件保留原样，不表示本版全部执行；部分旧的 0.375 比例地理夹具不能用于当前 0.5 比例。

富士山约 Y1882，最高可建造 Y1999。精度取舍见 docs/COMPACT-OFFLINE.md，许可见 ATTRIBUTION.md 与 THIRD_PARTY_LICENSES。
