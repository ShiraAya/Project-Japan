#!/usr/bin/env python3
"""Strict 0.1.24 lake/shore repair; compile pure Java runtime and preserve 0.1.23 game adapters.

Pin unchanged game adapters, projection, DEM nodes and hydro solver; permit continuous missing-node interpolation, reviewed harbour masks and rebaked startup data.
This is not a full ForgeGradle build. Normal development builds remain ./gradlew check build.
"""
import argparse,hashlib,subprocess,zipfile,shutil,json
from pathlib import Path
from build_core_release import class_info
ROOT=Path(__file__).resolve().parents[1]
CORE='com/sora/pjr/core/';FORGE='com/sora/pjr/forge/'
BASE_JAR='750813a1238d60fbba40c29443722be35d9f0a39e1b111a8892fb5fc7f67b757'
BASE_SOURCE='4d5f8e7ac6df8c983118fd200682b1deac3a7d241236338278c5f705adaa49be'
NEW_ASSET='assets/pjr/world/hydraulic-startup.bin.gz'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--baseline-jar',type=Path,required=True);p.add_argument('--baseline-source',type=Path,required=True);a=p.parse_args()
 assert sha(a.baseline_jar)==BASE_JAR and sha(a.baseline_source)==BASE_SOURCE,'Wrong pinned baseline'
 with zipfile.ZipFile(a.baseline_source) as src:
  prefix='ProjectJapanRefined/src/main/java/'
  expected={n[len(prefix):] for n in src.namelist() if n.startswith(prefix+FORGE) and n.endswith('.java')}
  actual={f.relative_to(ROOT/'src/main/java').as_posix() for f in (ROOT/'src/main/java'/FORGE).glob('*.java')}
  assert expected==actual,'Forge source set changed'
  for n in (expected-{FORGE+'WorldRuntime.java',FORGE+'PjrChunkGenerator.java'})|{CORE+'Geo.java'}:assert src.read(prefix+n)==(ROOT/'src/main/java'/n).read_bytes(),'Forge contract changed: '+n
  assert src.read(prefix+FORGE+'PjrChunkGenerator.java')==(ROOT/'src/main/java'/FORGE/'PjrChunkGenerator.java').read_bytes()
  old_core={n[len(prefix):]:src.read(n) for n in src.namelist() if n.startswith(prefix+CORE) and n.endswith('.java')}
  new_core={f.relative_to(ROOT/'src/main/java').as_posix():f.read_bytes() for f in (ROOT/'src/main/java'/CORE).glob('*.java')}
  assert set(new_core)==set(old_core)
  for n,b in old_core.items():
   if n not in {CORE+'PrecisionTerrain.java',CORE+'TiledRaster.java'}:assert new_core[n]==b,'Terrain or solver code changed: '+n
 classes=ROOT/'build/classes/java/main';shutil.rmtree(classes,ignore_errors=True);classes.mkdir(parents=True)
 subprocess.run(['java','-XX:-UsePerfData','-m','jdk.compiler/com.sun.tools.javac.Main','--release','17','-encoding','UTF-8','-d',str(classes)]+[str(f) for f in sorted((ROOT/'src/main/java'/CORE).glob('*.java'))]+[str(ROOT/'src/main/java'/FORGE/'WorldRuntime.java')],check=True)
 with zipfile.ZipFile(a.baseline_jar) as old:
  entries={n:old.read(n) for n in old.namelist() if not n.endswith('/') and not n.startswith(CORE) and not n.startswith(FORGE+'WorldRuntime')}
  previous={class_info(old.read(n))['name']:class_info(old.read(n)) for n in old.namelist() if n.endswith('.class')}
 fresh={f.relative_to(classes).as_posix():f.read_bytes() for f in classes.rglob('*.class')}
 current={class_info(b)['name']:class_info(b) for b in fresh.values()}
 for info in current.values():
  assert info['major']==61
  assert not any(n.startswith(('net/minecraft/','net/minecraftforge/','java/net/')) for n in info['classes'])
 for owner,info in previous.items():
  if owner.startswith(CORE) and info['flags']&0x4000:
   assert [k for k,v in info['members'].items() if v&0x4000]==[k for k,v in current[owner]['members'].items() if v&0x4000],'Enum order changed'
 refs=set();adapters={n:b for n,b in entries.items() if n.startswith(FORGE) and n.endswith('.class')}
 for raw in adapters.values():
  info=class_info(raw)
  for owner,kind,name,descriptor in info['refs']:
   if not (owner.startswith(CORE) or owner==FORGE+'WorldRuntime'):continue
   key=(kind,name,descriptor);before=previous[owner]['members'].get(key);after=current[owner]['members'].get(key)
   if key==('method','ordinal','()I') and previous[owner]['parent']==current[owner]['parent']=='java/lang/Enum':before=after=0x11
   assert before is not None and after is not None and after&1 and (before&8)==(after&8),'Incompatible core ABI: '+str((owner,key))
   refs.add((owner,key))
  for owner in info['classes']:
   if owner.startswith(CORE):assert owner in current and current[owner]['flags']&1
 resources={f.relative_to(ROOT/'src/main/resources').as_posix():f.read_bytes() for f in (ROOT/'src/main/resources').rglob('*') if f.is_file()}
 old_assets={n:b for n,b in entries.items() if n.startswith('assets/pjr/')}
 coast_report=json.loads((ROOT/'docs/asset-changes-0.1.24.json').read_text())
 assert coast_report['baseline_jar_sha256']==BASE_JAR
 coast_assets={r['path']:r for r in coast_report['changed_assets']}
 assert set(resources)&set(old_assets)==set(old_assets)
 for n,r in coast_assets.items():
  assert n.startswith('assets/pjr/terrain/urban-coast/packs/') or n==NEW_ASSET
  assert hashlib.sha256(old_assets[n]).hexdigest()==r['before_sha256']
  assert hashlib.sha256(resources[n]).hexdigest()==r['after_sha256']
 assert {n for n in resources if n.startswith('assets/pjr/')}==set(old_assets)
 for n,b in old_assets.items():
  if n not in coast_assets:assert resources[n]==b,'Unreviewed terrain asset changed: '+n
 entries.update(fresh);entries.update(resources)
 version=next(s.split('=',1)[1] for s in (ROOT/'gradle.properties').read_text().splitlines() if s.startswith('mod_version='))
 assert version=='0.1.24-alpha','This tool is pinned to the reviewed performance release'
 entries['META-INF/mods.toml']=entries['META-INF/mods.toml'].replace(b'${version}',version.encode())
 entries['META-INF/MANIFEST.MF']=('Manifest-Version: 1.0\r\nImplementation-Title: ProjectJapanRefined\r\nImplementation-Version: '+version+'\r\n\r\n').encode()
 jar=ROOT/f'build/libs/ProjectJapanRefined-{version}.jar';jar.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
  for n,b in sorted(entries.items()):
   info=zipfile.ZipInfo(n,(2026,10,8,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
   out.writestr(info,b,compresslevel=9)
 assert jar.stat().st_size<=50_000_000,'Strict 50 MB budget exceeded'
 with zipfile.ZipFile(jar) as z:
  assert z.testzip() is None
  for n,b in adapters.items():assert z.read(n)==b
 report='PJR water/coast release assembly PASS\n'
 report+=f'version={version}\njarSHA256={sha(jar)}\njarBytes={jar.stat().st_size}\n'
 report+=f'freshCoreAndRuntimeClasses={len(current)}\nunchangedGameAdapterSourceFiles={len(expected)-1}\nunchangedReobfuscatedAdapterClasses={len(adapters)}\nsameLengthDebugCountPatchedClasses=0\ncompatibleCoreMemberReferences={len(refs)}\n'
 report+=f'baselineJarSHA256={BASE_JAR}\nbaselineSourceSHA256={BASE_SOURCE}\n'
 report+=f'reviewedCoastOrStartupAssets={len(coast_assets)}\noriginalDEMAndUnlistedAssetsByteParity=PASS\njavaClassVersion=61\narchiveIntegrity=PASS\nsizeLimitBytes=50000000\n'
 report+='Build method: freshly compiled core with 0.1.23 reobfuscated game adapters; pure Java WorldRuntime rebuilt.\nNo new ForgeGradle, ProtoChunk, graphical client, lighting, or fluid-tick execution is claimed.\n'
 dest=ROOT/'build/reports/assembly-validation.txt';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(report);print(report)
if __name__=='__main__':main()
