#!/usr/bin/env python3
"""Offline pruning of narrow coast-attached marine spurs in bounded harbour windows.

Decode only packaged class masks; retain coastal/inland land and every unchanged tile.
Regenerate affected distance fields with the existing procedural-coast-v1 codec.
"""
import argparse, gzip, json, math, struct, hashlib
from pathlib import Path
import numpy as np
from scipy import ndimage
from compact_coast import packed_mask, signed_varints

ROOT=Path(__file__).resolve().parents[1]
def xy(lon,lat):return ((lon+180)/360*16384,(1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*16384)
def load_tiles(folder):
 result={}
 for p in sorted((folder/'packs').glob('*.pck')):
  z,bx,by=map(int,p.stem.split('-'));b=p.read_bytes();magic,n=struct.unpack_from('>IH',b);assert magic==0x504a5250;start=6+9*n
  for i in range(n):
   slot,off,size=struct.unpack_from('>BII',b,6+i*9)
   result[(bx*4+slot%4,by*4+slot//4)]=b[start+off:start+off+size]
 return result
def mask_from(raw):
 b=gzip.decompress(raw);magic,v,w,h,ox,oy,pixel=struct.unpack_from('>6Id',b);assert (magic,v)==(0x504a5243,1)
 n=w*h//8;a=np.unpackbits(np.frombuffer(b,dtype='uint8',count=n,offset=32)).reshape(h,w)
 a+=2*np.unpackbits(np.frombuffer(b,dtype='uint8',count=n,offset=32+n)).reshape(h,w)
 return a[oy:oy+512,ox:ox+512]
def coarse(mask):
 out=[]
 for wet in [mask[::8,::8]==1,mask[::8,::8]!=0]:
  d=ndimage.distance_transform_edt(~wet)-ndimage.distance_transform_edt(wet)
  out.append(np.rint(np.sign(d)*d*d).astype('int32'))
 return out
def main():
 p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);a=p.parse_args()
 folder=ROOT/'src/main/resources/assets/pjr/terrain/urban-coast';tiles=load_tiles(a.baseline)
 reports=[];changes=[];probes=[]
 for line in (folder/'regions.tsv').read_text().splitlines():
  if not line or line.startswith('#'):continue
  name,*b=line.split('\t')
  # Inspect every packaged urban harbour window.
  west,south,east,north=map(float,b);x0,y0=map(int,xy(west,north));x1,y1=map(int,xy(east,south))
  mask=np.zeros(((y1-y0+1)*512,(x1-x0+1)*512),dtype='uint8')
  for y in range(y0,y1+1):
   for x in range(x0,x1+1):mask[(y-y0)*512:(y-y0+1)*512,(x-x0)*512:(x-x0+1)*512]=mask_from(tiles[(x,y)])
  pixel=40075016.68557849/16384/512*math.cos(math.radians((south+north)/2))
  land=mask==0
  radius=max(1,int(math.ceil(16/pixel)))
  yy,xx=np.ogrid[-radius:radius+1,-radius:radius+1]
  footprint=xx*xx+yy*yy<=radius*radius
  opened=ndimage.binary_opening(land,structure=footprint)
  residue=land & ~opened
  # Frame edges lack neighbours; inland-water margins are outside this policy.
  residue[:radius+2]=False;residue[-radius-2:]=False
  residue[:,:radius+2]=False;residue[:,-radius-2:]=False
  protected=ndimage.binary_dilation(mask==2,iterations=radius+2)
  labels,n=ndimage.label(residue,np.ones((3,3),dtype=bool))
  counts=np.bincount(labels.ravel());remove=(counts*pixel*pixel<=100000);remove[0]=False
  remove[np.unique(labels[protected])]=False
  objects=ndimage.find_objects(labels);entries=[]
  w,s,e,north=west,south,east,north
  for i in np.flatnonzero(remove):
   sy,sx=objects[i-1];lon=(x0+(sx.start+sx.stop)/1024)/16384*360-180
   lat=math.degrees(math.atan(math.sinh(math.pi*(1-2*(y0+(sy.start+sy.stop)/1024)/16384))))
   span=max(sy.stop-sy.start,sx.stop-sx.start)*pixel;area=counts[i]*pixel*pixel
   local=labels[sy,sx]==i
   width=max(0,(2*ndimage.distance_transform_edt(np.pad(local,1)).max()-1)*pixel)
   narrow=span>=96 and span>=10*max(width,pixel) and width<=32 and span<=8192
   if not(w<lon<e and s<lat<north) or not narrow:remove[i]=False;continue
   # Preserve a narrow isthmus joining two broad pieces of land. A harbour
   # spur has one broad root; an isolated sliver has none.
   ay=max(0,sy.start-radius-2);by=min(mask.shape[0],sy.stop+radius+2)
   ax=max(0,sx.start-radius-2);bx=min(mask.shape[1],sx.stop+radius+2)
   adjacent=ndimage.binary_dilation(labels[ay:by,ax:bx]==i,iterations=2)
   cores,ncore=ndimage.label(opened[ay:by,ax:bx],np.ones((3,3),dtype=bool))
   contacts=np.unique(cores[adjacent]);contacts=contacts[contacts!=0]
   if len(contacts)>1:remove[i]=False;continue
   entries.append(dict(id=int(i),nodes=int(counts[i]),area_m2=round(float(area),2),span_m=round(float(span),2),max_width_m=round(float(width),2),reason='coast_attached_spur' if len(contacts)==1 else 'thin_fragment',lon=lon,lat=lat))
  del land,opened,residue,protected
  old_fields=coarse(mask);dots=remove[labels];del labels
  before=mask.copy();mask[dots]=1;fields=coarse(mask)
  for yy,xx in zip(*np.nonzero(dots)):
   lon=(x0+(xx+.5)/512)/16384*360-180
   lat=math.degrees(math.atan(math.sinh(math.pi*(1-2*(y0+(yy+.5)/512)/16384))))
   wx=round((lon-139.767125)*111320*math.cos(math.radians(35.681236))/2)
   wz=round((35.681236-lat)*111320/2)
   probes.append((wx,wz,name))
  different=(old_fields[0]!=fields[0])|(old_fields[1]!=fields[1]);del old_fields
  changed_tiles=0
  for y in range(y0,y1+1):
   for x in range(x0,x1+1):
    px=(x-x0)*512;py=(y-y0)*512;ax=max(0,px-48);ay=max(0,py-48);bx=min(mask.shape[1],px+560);by=min(mask.shape[0],py+560)
    cy=np.minimum(np.arange(65)+py//8,fields[0].shape[0]-1);cx=np.minimum(np.arange(65)+px//8,fields[0].shape[1]-1)
    if not(dots[ay:by,ax:bx].any() or different[cy[:,None],cx[None,:]].any()):continue
    local=mask[ay:by,ax:bx];raw=bytearray(struct.pack('>6Id',0x504a5243,1,local.shape[1],local.shape[0],px-ax,py-ay,pixel));raw+=packed_mask(local)
    for f in fields:
     values=f[cy[:,None],cx[None,:]];delta=values.copy();delta[1:,:]-=values[:-1,:];delta[:,1:]-=delta[:,:-1].copy();raw+=signed_varints(delta)
    raw+=struct.pack('>I',0);tiles[(x,y)]=gzip.compress(raw,compresslevel=9,mtime=0);changed_tiles+=1
  assert np.all(mask[before==2]==2) and np.all((mask!=before)==dots)
  reports.append(dict(region=name,removed_components=len(entries),removed_nodes=int(dots.sum()),changed_tiles=changed_tiles,components=entries))
  changes.extend(entries);print(name,len(entries),'components',changed_tiles,'tiles',flush=True)
  del mask,before,dots,fields,different
 # Repack all tiles; untouched payloads are copied verbatim.
 packs={}
 for (x,y),b in tiles.items():packs.setdefault((x//4,y//4),[]).append(((y%4)*4+x%4,b))
 for (x,y),rows in packs.items():
  head=bytearray(struct.pack('>IH',0x504a5250,len(rows)));body=bytearray()
  for slot,b in sorted(rows):head+=struct.pack('>BII',slot,len(body),len(b));body+=b
  (folder/'packs'/f'14-{x}-{y}.pck').write_bytes(head+body)
 report=dict(policy='Narrow marine spurs after 16m-radius opening, maximum residual width32m, span96..8192m, elongation>=10, area<=100000m2, at most one broad land root. Inland-water margins, frame boundaries and isthmuses with two broad roots protected. This gameplay simplification does not classify natural versus artificial structures.',regions=reports)
 (ROOT/'docs/port-fragments-0.1.24.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'data/port-probes-0.1.24.csv').write_text('x,z,region\n'+''.join(f'{x},{z},{n}\n' for x,z,n in probes))
 print('PORT SPURS PASS',len(changes),'components',flush=True)
if __name__=='__main__':main()
