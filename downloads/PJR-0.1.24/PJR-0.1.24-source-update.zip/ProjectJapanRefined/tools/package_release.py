#!/usr/bin/env python3
"""Package the validated PJR source tree and built mod without build caches or logs."""
import argparse
import io
import os
import hashlib
import json
import re
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def atomic_bytes(path,data):
    staged=path.with_name(path.name+'.part')
    with staged.open('wb') as handle:
        handle.write(data);handle.flush();os.fsync(handle.fileno())
    if staged.stat().st_size!=len(data):raise ValueError('Incomplete staged artifact')
    os.replace(staged,path)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    release = json.loads((ROOT / 'RELEASE.json').read_text())
    if not release.get('release_ready') or release.get('status') != 'validated_alpha':
        raise ValueError('Release gates are incomplete; do not package a checkpoint as a release')
    version = release['version']
    jar = ROOT / f'build/libs/ProjectJapanRefined-{version}.jar'
    if jar.stat().st_size > 50_000_000 or not release.get('fully_offline'):
        raise ValueError('Offline 50 MB release requirement not met')
    with zipfile.ZipFile(jar) as archive:
        if archive.testzip() is not None:
            raise ValueError('Corrupt JAR')
        if any('assets/pjr/terrain/'+n+'.pjrt.gz' in archive.namelist() for n in ['tokyo-bay','tokyo-bay-outer']):
            raise ValueError('Retired Tokyo overlay is still packaged')
        for file in (ROOT / 'src/main/resources/assets/pjr').rglob('*'):
            if file.is_file() and archive.read(file.relative_to(ROOT / 'src/main/resources').as_posix()) != file.read_bytes():
                raise ValueError('JAR has outdated asset: ' + str(file))
        if f'version="{version}"' not in archive.read('META-INF/mods.toml').decode():
            raise ValueError('JAR version does not match RELEASE.json')
    binary_report=(ROOT/'docs/validation/release-binary-validation.txt').read_text()
    if 'jarSHA256='+digest(jar)+'\n' not in binary_report:
        raise ValueError('Final JAR validation belongs to another binary')
    atomic_bytes(output / jar.name,jar.read_bytes())
    reports = ['scale-precision-validation.txt', 'precision-atlas-validation.txt', 'forge-validation.txt', 'flower-validation.txt', 'release-binary-validation.txt', 'lake-network-validation.txt']
    if release.get('validation_scope') == 'performance_core_0.1.17':
        reports = ['scale-precision-validation.txt', 'release-binary-validation.txt', 'lake-network-validation.txt',
                   'assembly-validation.txt', 'performance-validation.txt', 'hydrology-parity.txt',
                   'coast-decoder-parity.txt', 'concurrent-validation.txt']
    if release.get('validation_scope') == 'startup_portability_0.1.18':
        reports = ['release-binary-validation.txt', 'assembly-validation.txt', 'hydrology-parity.txt',
                   'final-normal.txt', 'final-portable-math.txt', 'final-no-libm.txt',
                   'final-integrity.txt', 'final-startup-fuji.txt', 'final-module.txt']
    if release.get('validation_scope') == 'water_coast_0.1.19':
        reports = ['release-binary-validation.txt', 'assembly-validation.txt',
                   'final-hydrology-validation.txt', 'final-portable-startup.txt',
                   'feedback-after.txt', 'river-gap-validation.txt', 'final-pjm-bundle.txt',
                   'final-pjm-compatibility.txt']
    if release.get('validation_scope') == 'feedback_0.1.20':
        reports = ['release-binary-validation.txt', 'assembly-validation.txt',
                   'final-hydrology-validation.txt', 'final-portable-startup.txt',
                   'final-port-strips.txt', 'river-gap-validation.txt', 'shore-after.txt',
                   'final-map-coverage.txt', 'final-pjm-bundle.txt', 'final-pjm-compatibility.txt']
    if release.get('validation_scope') == 'incision_0.1.21':
        reports = ['release-binary-validation.txt', 'assembly-validation.txt',
                   'final-hydrology.txt', 'final-incision-summary.txt', 'final-shores.txt',
                   'final-coast.txt', 'final-pjm-bundle.txt', 'final-pjm-compatibility.txt']
    if release.get('validation_scope') == 'outlet_0.1.22':
        reports = ['release-binary-validation.txt', 'assembly-validation.txt',
                   'outlet-landscape-validation.txt', 'final-hydrology.txt',
                   'near-bank.txt', 'pjm-compatibility.txt', 'pjm-cache.txt']
    if release.get('validation_scope') == 'coast_dem_0.1.24':
        reports = ['assembly-0.1.24.txt', 'dem-boundaries-0.1.24.txt',
                   'feedback-coast-0.1.24.txt', 'coast-masks-0.1.24.txt',
                   'network-0.1.24.txt', 'scale-0.1.24.txt']
    for name in reports:
        if not re.search(r'\bPASS(?:\s|$)', (ROOT/'docs/validation'/name).read_text()):
            raise ValueError('Missing successful verification report: '+name)
    excluded = {'build', '.gradle', '.git', 'run', 'logs', 'source-archives', '__pycache__', '.idea'}
    files = [p for p in ROOT.rglob('*') if p.is_file()
             and not excluded.intersection(p.relative_to(ROOT).parts)
             and p.name != 'SOURCE-SHA256SUMS.txt'
             and p.suffix not in {'.pyc', '.log'}]
    manifest = ROOT / 'SOURCE-SHA256SUMS.txt'
    manifest.write_text(''.join(digest(p) + '  ' + p.relative_to(ROOT).as_posix() + '\n' for p in sorted(files)))
    files.append(manifest)
    source = output / f'ProjectJapanRefined-{version}-source.zip'
    archive_bytes=io.BytesIO()
    with zipfile.ZipFile(archive_bytes, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for file in sorted(files):
            info = zipfile.ZipInfo('ProjectJapanRefined/' + file.relative_to(ROOT).as_posix(), (2026, 10, 8, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o100755 if file.name == 'gradlew' else 0o100644) << 16
            archive.writestr(info, file.read_bytes())
    atomic_bytes(source,archive_bytes.getvalue())
    with zipfile.ZipFile(source) as archive:
        if archive.testzip() is not None:
            raise ValueError('Corrupt source ZIP')
    # Validation reports and geographic previews are included in the source ZIP.
    sums_name=f'ProjectJapanRefined-{version}-SHA256SUMS.txt'
    artifacts=[output/jar.name,source]
    atomic_bytes(output / sums_name,''.join(digest(p) + '  ' + p.name + '\n'
        for p in sorted(artifacts)).encode())
    for file in sorted(artifacts+[output/sums_name]):
        print(file.name, file.stat().st_size, 'bytes')

if __name__ == '__main__':
    main()
