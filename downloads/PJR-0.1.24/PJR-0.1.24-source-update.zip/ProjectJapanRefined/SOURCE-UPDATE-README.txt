Apply over ProjectJapanRefined-0.1.23-alpha-source.zip (SHA256 4d5f8e7ac6df8c983118fd200682b1deac3a7d241236338278c5f705adaa49be).
Extract into its parent folder, replacing matching files. This is a source update, not the installable mod.
The unchanged 0.1.23 files plus this patch reproduce the full 0.1.24 source tree.
